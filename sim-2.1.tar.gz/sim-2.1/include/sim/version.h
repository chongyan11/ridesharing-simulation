////////////////////////////////////////////////////////////////////////
//                                                                    //
// version.h                                                          //
//                                                                    //
// standard defines                                                   //
//                                                                    //
// (c) 1995 D. Bolier, A. Eliens                                      //
//                                                                    //
////////////////////////////////////////////////////////////////////////

#ifndef SIM_VERSION_H
#define SIM_VERSION_H

#ifndef HUSH
#define HUSH
#endif

#ifndef SIM
#define SIM
#endif

#endif
